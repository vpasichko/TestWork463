<?php
/**
 *
 * Template name: Create_product
 *
 */

 get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php 
		$attachment_id = '';
		$message = '';
		if (isset($_POST['submit_btn'])) { 

			
			if (isset($_FILES['product_url']['name'])) {
				require_once( ABSPATH . 'wp-admin/includes/image.php' );
				require_once( ABSPATH . 'wp-admin/includes/file.php' );
				require_once( ABSPATH . 'wp-admin/includes/media.php' );
				$attachment_id = media_handle_upload( 'product_url', 0 );
			}

			if (isset($_FILES['product_url']['name']) && isset($_POST['title_product']) && isset($_POST['price_product']) && isset($_POST['type_product']) && isset($_POST['date_publish_product'])) {
				
				$post_data = array(                                                  
					'post_date_gmt'  => date("Y-m-d H:i:s"),                                        
					'post_status'    => 'publish',
					'post_title'     => $_POST['title_product'],                                                  
					'post_type'      => 'product',                                
					'meta_input'     => [ 'product_type' => $_POST['type_product'], 'date_publish' => $_POST['date_publish_product'], '_regular_price' => $_POST['price_product'], '_price' => $_POST['price_product'], 'image_id' => $attachment_id ],                             
				);

				$post_id = wp_insert_post( wp_slash($post_data) );

				set_post_thumbnail( $post_id, $attachment_id );
				
				unset($_POST['title_product']); 
				unset($_POST['price_product']); 
				unset($_POST['type_product']); 
				unset($_POST['date_publish_product']); 
				unset($_FILES); 
				$message = 'Товар успешно добавлен';

			}  else{
				$message = 'Заполните все поля верно!';
			}


		}

		?>
		<div class="table_row table_row_message"> 
			<p><?=$message; ?></p>
		</div>
		<div id="form_add_product">
			<form name="add_product" method="POST" action="" enctype="multipart/form-data" autocomplete="off" accept-charset="utf-8">
					
					<div class="title_list">
						<p>Добавление товара</p>
					</div>

			        <div class="table_row">                             

			            <div class="table_photo values">
			            	<?php if (isset($_FILES['product_url']['name'])) {?>

			            		<img class="img_product" src="<?php echo wp_get_attachment_image_url($attachment_id, 'medium'); ?> ">
			            	<?php } else { ?>
			               		<img class="img_product" style="display:none;">
			               	<?php } ?>
			                <input type="file" name="product_url" hidden="hidden" id="product_file">
			                <input type="hidden" name="pic_url" value="">
			                <label for="product_file" id="label_product_file">Выбрать фото</label>
			            </div>
			        </div>
			    	
			    	<div class="table_row">
			    		<div class="table_row_item">
			    			<input type="text" name="title_product" value="<?php if(isset($_POST['title_product'])) echo $_POST['title_product'];?>" placeholder="Наименование товара">
			    		</div>
			    		<div class="table_row_item">
			    			<input type="text" name="price_product" value="<?php if(isset($_POST['price_product'])) echo $_POST['price_product'];?>" placeholder="Цена товара">
			    		</div>
			    	</div>

			    	<div class="table_row">
			    		<div class="table_row_item">
				    		<select name="type_product">
				    			<option value="" disabled selected>Выберите тип товара</option>

				    			
				    			<option value="rare" <?php if (isset($_POST['type_product']) && $_POST['type_product'] == 'rare') echo "selected";?>>rare</option>
				    			<option value="frequent" <?php if (isset($_POST['type_product']) && $_POST['type_product'] == 'frequent') echo "selected";?>>frequent</option>
				    			<option value="unusual" <?php if (isset($_POST['type_product']) && $_POST['type_product'] == 'unusual') echo "selected";?>>unusual</option>
				    		</select>
				    	</div>
				    	<div class="table_row_item">
				    		<?php $current_date = date("d.m.y"); ?>
				    		<span>Дата создания товара</span>
				    		<input type="text" id="input_date_publish" value="<?php echo $current_date; ?>" hidden name="date_publish_product" 
								/>
							<label for="input_date_publish" style="margin: 0;font-size: 18px;cursor: default;"><?php echo $current_date; ?></label>
						</div>
			    	</div>
			   

				    <div class="table_row">
				        <button type="submit" name="submit_btn">
				            Сохранить
				        </button>
			   		</div>

			</form>
		</div>

		<?php
			while ( have_posts() ) :
				the_post();

				do_action( 'storefront_page_before' );

				//get_template_part( 'content', 'page' );

				/**
				 * Functions hooked in to storefront_page_after action
				 *
				 * @hooked storefront_display_comments - 10
				 */
				do_action( 'storefront_page_after' );

			endwhile; // End of the loop.
			


			
			?>

		</main><!-- #main -->
	</div><!-- #primary -->
<?php
get_footer();