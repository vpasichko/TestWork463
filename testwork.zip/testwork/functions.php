<?php 

/**
 * Storefront engine room
 *
 * @package storefront
 */

/**
 * Assign the Storefront version to a var
 */
$theme              = wp_get_theme( 'storefront' );
$storefront_version = $theme['Version'];

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 980; /* pixels */
}

$storefront = (object) array(
	'version'    => $storefront_version,

	/**
	 * Initialize all the things.
	 */
	'main'       => require 'inc/class-storefront.php',
	'customizer' => require 'inc/customizer/class-storefront-customizer.php',
);

require 'inc/storefront-functions.php';
require 'inc/storefront-template-hooks.php';
require 'inc/storefront-template-functions.php';
require 'inc/wordpress-shims.php';

if ( class_exists( 'Jetpack' ) ) {
	$storefront->jetpack = require 'inc/jetpack/class-storefront-jetpack.php';
}

if ( storefront_is_woocommerce_activated() ) {
	$storefront->woocommerce            = require 'inc/woocommerce/class-storefront-woocommerce.php';
	$storefront->woocommerce_customizer = require 'inc/woocommerce/class-storefront-woocommerce-customizer.php';

	require 'inc/woocommerce/class-storefront-woocommerce-adjacent-products.php';

	require 'inc/woocommerce/storefront-woocommerce-template-hooks.php';
	require 'inc/woocommerce/storefront-woocommerce-template-functions.php';
	require 'inc/woocommerce/storefront-woocommerce-functions.php';
}

if ( is_admin() ) {
	$storefront->admin = require 'inc/admin/class-storefront-admin.php';

	require 'inc/admin/class-storefront-plugin-install.php';
}

/**
 * NUX
 * Only load if wp version is 4.7.3 or above because of this issue;
 * https://core.trac.wordpress.org/ticket/39610?cversion=1&cnum_hist=2
 */
if ( version_compare( get_bloginfo( 'version' ), '4.7.3', '>=' ) && ( is_admin() || is_customize_preview() ) ) {
	require 'inc/nux/class-storefront-nux-admin.php';
	require 'inc/nux/class-storefront-nux-guided-tour.php';
	require 'inc/nux/class-storefront-nux-starter-content.php';
	}

wp_enqueue_style( 'custom_css', get_template_directory_uri() .'/assets/css/custom.css');
wp_enqueue_script('scripts', get_template_directory_uri() .'/assets/js/scripts.js', '', '', true );


//add text field
function add_product_type_field() {

	global $product, $post;

	echo '<div class="product_type">'; 

	woocommerce_wp_select( array(
	   'id'      => 'product_type',
	   'label'   => 'Тип продукта',
	   'options' => array(
	   		'' => __( 'Выберите тип продукта', 'woocommerce' ),
	    	'rare'   => __( 'rare', 'woocommerce' ),
	    	'frequent'   => __( 'frequent', 'woocommerce' ),
	    	'unusual' => __( 'unusual', 'woocommerce' ),
	   ),
	) );

	echo '</div>'; 
	
}


add_action( 'woocommerce_product_options_pricing', 'add_product_type_field' );


//save text field
function save_product_type_field( $post_id ) {

	$field = $_POST['product_type'];
	if ( ! empty( $field ) ) {
		update_post_meta( $post_id, 'product_type', esc_attr( $field ) );
	}

	
}

add_action( 'woocommerce_process_product_meta', 'save_product_type_field', 10 );



//add image
add_action( 'add_meta_boxes', 'add_metabox_image' );
function add_metabox_image () {
	add_meta_box( 'image_box', 'Главное изображение товара', 'add_metabox_image_func', 'product', 'side', 'low');
}

function add_metabox_image_func ( $post ) {
	global $content_width, $_wp_additional_image_sizes;

	$image_id = get_post_meta( $post->ID, 'image_id', true );

	$old_content_width = $content_width;
	$content_width = 254;

	if ( $image_id && get_post( $image_id ) ) {

		if ( ! isset( $_wp_additional_image_sizes['post-thumbnail'] ) ) {
			$thumbnail_html = wp_get_attachment_image( $image_id, array( $content_width, $content_width ) );
		} else {
			$thumbnail_html = wp_get_attachment_image( $image_id, 'post-thumbnail' );
		}

		if ( ! empty( $thumbnail_html ) ) {
			$content = $thumbnail_html;
			$content .= '<p><a href="javascript:;" id="remove_image_button" >Удалить изображение</a></p>';
			$content .= '<input type="hidden" id="upload_image" name="product_image" value="' . esc_attr( $image_id ) . '" />';
		}

		$content_width = $old_content_width;
	} else {

		$content = '<img src="" style="width:' . esc_attr( $content_width ) . 'px;height:auto;border:0;display:none;" />';
		$content .= '<p><a title="Установить изображение" href="javascript:;" id="upload_image_button" id="set_image" data-uploader_title="Установить изображение" data-uploader_button_text="Установить изображение">Установить изображение</a></p>';
		$content .= '<input type="hidden" id="upload_image" name="product_image" value="" />';

	}

	echo $content;
}

//save image
add_action( 'save_post', 'save_image', 10, 1 );
function save_image ( $post_id ) {
	if( isset( $_POST['product_image'] ) ) {
		$image_id = (int) $_POST['product_image'];
		update_post_meta( $post_id, 'image_id', $image_id );
	}
}


//add date field
function add_product_date_publish_field() {

	global $product, $post;

	if (get_post_meta( $post->ID, 'date_publish', true ) == '') {
		$current_date = date("d.m.y"); 
	} else{
		$current_date = get_post_meta( $post->ID, 'date_publish', true );
	} 

	echo '<div class="product_date_publish">'; 
	?>


	<p class="form-field date_field">
		<label for="date_field">
			<?php echo 'Дата создания товара'; ?>
		</label>
		
			<input type="text" id="input_date_publish" hidden disabled  name="date_publish" value="<?php echo $current_date; ?>"
				/>
			<label for="input_date_publish" style="margin: 0;font-size: 14px;cursor: default;"><?php echo $current_date; ?></label>
	</p>

	<?php 
	echo '</div>'; 
	
}


add_action( 'woocommerce_product_options_pricing', 'add_product_date_publish_field' );


//save text field
function save_product_date_publish_field( $post_id ) {

	$field = $_POST['date_publish'];
	if ( ! empty( $field ) ) {
		update_post_meta( $post_id, 'date_publish', esc_attr( $field ) );
	}

	
}

add_action( 'woocommerce_process_product_meta', 'save_product_date_publish_field', 10 );


//add control button
add_action( 'add_meta_boxes', 'add_metabox_control' );
function add_metabox_control () {
	add_meta_box( 'control_box', 'Управление', 'add_control_func', 'product', 'side', 'low');
}


function add_control_func( $post_id ) {

	echo '<button name="clear_custom_fields" id="clear_custom_fields" class="button button-primary button-large" value="Очистить поля">Очистить поля</button><button name="save_product" id="save_product" class="button button-primary button-large" value="Обновить товар" style="float:right;">Обновить товар</button>';

	
}


//clear custom fields
add_action('wp_ajax_clear_custom_fields' , 'clear_custom_fields_ajax');
add_action('wp_ajax_nopriv_clear_custom_fields','clear_custom_fields_ajax');

function clear_custom_fields_ajax(){
    $id_product = $_POST['id_product'];
  	
  	update_post_meta( $id_product , 'date_publish', '' );
  	update_post_meta( $id_product , 'image_id', '' );
  	update_post_meta( $id_product , 'product_type', '' );

}


//save product
add_action('wp_ajax_save_product' , 'save_product_ajax');
add_action('wp_ajax_nopriv_save_product','save_product_ajax');

function save_product_ajax(){

    $result = false;

    if (isset($_POST['id_product'])) {
    	
    	$id_product = $_POST['id_product'];
    	$_product = wc_get_product( $id_product );
    	foreach ($_POST as $name_meta => $value){
		
			if (isset($_product->data[$name_meta])) {
				update_post_meta( $id_product, $name_meta, $value );  
			}
		}

		$post_update = array(
			'ID' => $id_product,
		    'post_title' => $_POST['post_title'],
		    'post_content'=> $_POST['description'],
		  );

		$ids_cat = $_POST['tax_input']['product_cat'];
		foreach ($ids_cat as &$row) {
		    $row = (int)$row;
		}
		
		wp_set_object_terms($id_product, $ids_cat, 'product_cat');
 		$result = wp_update_post( $post_update );

    }

  	wp_send_json_success (array(
    	'result' => $result,
	));

}
