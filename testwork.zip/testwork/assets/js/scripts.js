//upload image
jQuery(document).ready(function($) {

	var file_frame;

	jQuery.fn.upload_image = function( button ) {
		var button_id = button.attr('id');
		var field_id = button_id.replace( '_button', '' );

		if ( file_frame ) {
		  file_frame.open();
		  return;
		}

		file_frame = wp.media.frames.file_frame = wp.media({
		  title: jQuery( this ).data( 'uploader_title' ),
		  button: {
		    text: jQuery( this ).data( 'uploader_button_text' ),
		  },
		  multiple: false
		});

		file_frame.on( 'select', function() {
		  var attachment = file_frame.state().get('selection').first().toJSON();
		  jQuery("#"+field_id).val(attachment.id);
		  jQuery("#image_box img").attr('src',attachment.url);
		  jQuery( '#image_box img' ).show();
		  jQuery( '#' + button_id ).attr( 'id', 'remove_image_button' );
		  jQuery( '#remove_image_button' ).text( 'Удалить изображение' ).attr( {title:'Удалить изображение', 'data-uploader_title': 'Удалить изображение', 'data-uploader_button_text':'Удалить изображение'});

		});

		file_frame.open();
	};

	jQuery('#image_box').on( 'click', '#upload_image_button', function( event ) {
		event.preventDefault();
		jQuery.fn.upload_image( jQuery(this) );

	});

	jQuery('#image_box').on( 'click', '#remove_image_button', function( event ) {
		event.preventDefault();
		jQuery( '#upload_image' ).val( '' );
		jQuery( '#image_box img' ).attr( 'src', '' );
		jQuery( '#image_box img' ).hide();
		jQuery( this ).attr( 'id', 'upload_image_button' );
		jQuery( '#upload_image_button' ).text( 'Установить изображение' ).attr( {title:'Установить изображение', 'data-uploader_title': 'Установить изображение', 'data-uploader_button_text':'Установить изображение'});
	});

});

//clear custom fields
jQuery(document).on('click', '#clear_custom_fields', function(e){
	e.preventDefault();

	var id_product = jQuery('#post_ID').val(); 

	jQuery( '#upload_image' ).val( '' );
	jQuery( '#image_box img' ).attr( 'src', '' );
	jQuery( '#image_box img' ).hide();
	jQuery( '#remove_image_button' ).attr( 'id', 'upload_image_button' );
	jQuery( '#upload_image_button' ).text( 'Установить изображение' ).attr( {title:'Установить изображение', 'data-uploader_title': 'Установить изображение', 'data-uploader_button_text':'Установить изображение'});

	jQuery( '#product_type').val('');
	jQuery( '#input_date_publish').val('');
	jQuery( '#input_date_publish + label').html('');

	jQuery.ajax({
		url: '/wp-admin/admin-ajax.php',
		type: 'POST',
		data: "id_product=" + id_product + "&action=clear_custom_fields",
		
	});


});


//save product
jQuery(document).on('click', '#save_product', function(e){
	
	e.preventDefault();
	var id_product = jQuery('#post_ID').val(); 

	var json_text = jQuery('#post').find ('input:not([type="submit"]), textearea, select').serialize();

	var description = tinyMCE.activeEditor.getContent();

	jQuery.ajax({
		url: '/wp-admin/admin-ajax.php',
		type: 'POST',
		data: "id_product=" + id_product + "&" +  json_text + '&description=' + description + "&action=save_product",
		
		success: function(data) {

			if (data.data.result != false) {
				alert('Товар обновлен');
			}
			
		}
	});


});





jQuery(function(){
    //load image
    jQuery('#product_file').on('change',function(e){
        var preview = document.querySelector('.img_product');
        previewFile(this,preview);
    })
}) 

function previewFile(ele,preview) {
    if (ele.files[0]) {
    var blob = ele.files[0]; 
    var fileReader = new FileReader();
    fileReader.onloadend = function(e) {

        preview.style.display = "block";
        printImage(blob,preview);

    };
    fileReader.readAsArrayBuffer(blob);
    }
}

//preview image
function printImage(blob, preview) {
    var fr = new FileReader();
    fr.onloadend = function() {
        preview.src = fr.result;
    };
    fr.readAsDataURL(blob);
}

